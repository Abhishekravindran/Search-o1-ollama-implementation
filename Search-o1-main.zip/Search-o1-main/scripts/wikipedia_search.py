from langchain.utilities import WikipediaAPIWrapper
from typing import List, Dict
import json

def wikipedia_search(query: str, top_k: int = 5) -> List[Dict]:
    """
    Perform Wikipedia search using LangChain's Wikipedia wrapper.
    
    Args:
        query (str): The search query
        top_k (int): Number of results to return
        
    Returns:
        List[Dict]: List of search results with title, url, and content
    """
    wiki = WikipediaAPIWrapper()
    
    # Get search results
    search_results = wiki.search(query, max_results=top_k)
    
    # Format results
    formatted_results = []
    for title in search_results:
        try:
            # Get page content
            page_content = wiki.load(title)
            
            # Create result dictionary
            result = {
                'title': title,
                'url': f"https://en.wikipedia.org/wiki/{title.replace(' ', '_')}",
                'content': page_content,
                'snippet': page_content[:500] + "..." if len(page_content) > 500 else page_content
            }
            formatted_results.append(result)
        except Exception as e:
            print(f"Error fetching content for {title}: {e}")
            continue
            
    return formatted_results

def extract_relevant_info(results: List[Dict]) -> List[Dict]:
    """
    Extract relevant information from Wikipedia search results.
    
    Args:
        results (List[Dict]): List of search results
        
    Returns:
        List[Dict]: List of relevant information
    """
    relevant_info = []
    for result in results:
        info = {
            'title': result['title'],
            'url': result['url'],
            'snippet': result['snippet'],
            'content': result['content']
        }
        relevant_info.append(info)
    return relevant_info 