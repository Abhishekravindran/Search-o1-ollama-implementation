from typing import List, Dict, Optional
import ollama
from transformers import AutoTokenizer

class OllamaLLM:
    def __init__(self, model_name: str = "llama2", temperature: float = 0.7):
        """
        Initialize Ollama LLM wrapper.
        
        Args:
            model_name (str): Name of the Ollama model to use
            temperature (float): Sampling temperature
        """
        self.model_name = model_name
        self.temperature = temperature
        self.tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-2-7b-chat-hf")
        
    def generate(self, prompts: List[str], max_tokens: int = 2048) -> List[Dict]:
        """
        Generate text using Ollama model.
        
        Args:
            prompts (List[str]): List of input prompts
            max_tokens (int): Maximum number of tokens to generate
            
        Returns:
            List[Dict]: List of generated outputs
        """
        outputs = []
        for prompt in prompts:
            try:
                response = ollama.generate(
                    model=self.model_name,
                    prompt=prompt,
                    temperature=self.temperature,
                    max_tokens=max_tokens
                )
                outputs.append({
                    'text': response['response'],
                    'finish_reason': 'stop'
                })
            except Exception as e:
                print(f"Error generating response: {e}")
                outputs.append({
                    'text': '',
                    'finish_reason': 'error'
                })
        return outputs 