import os
import json
import time
from tqdm import tqdm
import argparse
from typing import List, Dict, Optional

from transformers import AutoTokenizer
from ollama_llm import OllamaLLM
from wikipedia_search import wikipedia_search, extract_relevant_info
from evaluate import run_evaluation, extract_answer
from prompts import (
    get_gpqa_search_o1_instruction,
    get_math_search_o1_instruction,
    get_code_search_o1_instruction,
    get_singleqa_search_o1_instruction,
    get_multiqa_search_o1_instruction,
    get_task_instruction_openqa,
    get_task_instruction_math,
    get_task_instruction_multi_choice,
    get_task_instruction_code,
)

# Define special tokens
BEGIN_SEARCH_QUERY = "<|begin_search_query|>"
END_SEARCH_QUERY = "<|end_search_query|>"
BEGIN_SEARCH_RESULT = "<|begin_search_result|>"
END_SEARCH_RESULT = "<|end_search_result|>"

def parse_args():
    parser = argparse.ArgumentParser(description="Run Search O1 with Ollama and Wikipedia search.")
    
    # Dataset configuration
    parser.add_argument(
        '--dataset_name',
        type=str,
        required=True,
        choices=['gpqa', 'math500', 'aime', 'amc', 'livecode', 'nq', 'triviaqa', 'hotpotqa', '2wiki', 'musique', 'bamboogle'],
        help="Name of the dataset to use."
    )
    
    parser.add_argument(
        '--split',
        type=str,
        required=True,
        choices=['test', 'diamond', 'main', 'extended'],
        help="Dataset split to use."
    )
    
    parser.add_argument(
        '--subset_num',
        type=int,
        default=-1,
        help="Number of examples to process. Defaults to all if not specified."
    )
    
    # Search configuration
    parser.add_argument(
        '--max_search_limit',
        type=int,
        default=10,
        help="Maximum number of searches per question."
    )
    
    parser.add_argument(
        '--max_turn',
        type=int,
        default=15,
        help="Maximum number of turns."
    )
    
    parser.add_argument(
        '--top_k',
        type=int,
        default=5,
        help="Maximum number of search documents to return."
    )
    
    # Ollama configuration
    parser.add_argument(
        '--ollama_model',
        type=str,
        default="llama2",
        help="Name of the Ollama model to use."
    )
    
    parser.add_argument(
        '--temperature',
        type=float,
        default=0.7,
        help="Sampling temperature."
    )
    
    return parser.parse_args()

def main():
    args = parse_args()
    
    # Extract arguments
    dataset_name = args.dataset_name
    split = args.split
    subset_num = args.subset_num
    MAX_SEARCH_LIMIT = args.max_search_limit
    MAX_TURN = args.max_turn
    top_k = args.top_k
    ollama_model = args.ollama_model
    temperature = args.temperature
    
    # Data paths
    if dataset_name == 'livecode':
        data_path = f'./data/LiveCodeBench/{split}.json'
    elif dataset_name in ['math500', 'gpqa', 'aime', 'amc']:
        data_path = f'./data/{dataset_name.upper()}/{split}.json'
    else:
        data_path = f'./data/QA_Datasets/{dataset_name}.json'
    
    # Load data
    with open(data_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
        if subset_num != -1:
            data = data[:subset_num]
    
    # Initialize Ollama LLM
    llm = OllamaLLM(model_name=ollama_model, temperature=temperature)
    
    # Initialize tokenizer for chat template
    tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-2-7b-chat-hf")
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = 'left'
    
    # Create output directory
    output_dir = f'./outputs/{dataset_name}.ollama.search_o1'
    os.makedirs(output_dir, exist_ok=True)
    
    # Process each question
    results = []
    for item in tqdm(data, desc="Processing questions"):
        question = item['Question']
        turn = 0
        search_count = 0
        executed_search_queries = set()
        
        # Get appropriate instruction based on dataset
        if dataset_name in ['nq', 'triviaqa']:
            instruction = get_singleqa_search_o1_instruction(MAX_SEARCH_LIMIT)
        elif dataset_name in ['hotpotqa', 'musique', 'bamboogle', '2wiki']:
            instruction = get_multiqa_search_o1_instruction(MAX_SEARCH_LIMIT)
        elif dataset_name in ['math500', 'aime', 'amc']:
            instruction = get_math_search_o1_instruction(MAX_SEARCH_LIMIT)
        elif dataset_name == 'gpqa':
            instruction = get_gpqa_search_o1_instruction(MAX_SEARCH_LIMIT)
        elif dataset_name == 'livecode':
            instruction = get_code_search_o1_instruction(MAX_SEARCH_LIMIT)
        
        # Get task-specific prompt
        if dataset_name in ['nq', 'triviaqa', 'hotpotqa', 'musique', 'bamboogle', '2wiki']:
            user_prompt = get_task_instruction_openqa(question)
        elif dataset_name in ['math500', 'aime', 'amc']:
            user_prompt = get_task_instruction_math(question)
        elif dataset_name == 'gpqa':
            user_prompt = get_task_instruction_multi_choice(question)
        elif dataset_name == 'livecode':
            question_title = item.get('question_title', '')
            user_prompt = get_task_instruction_code(question, question_title=question_title)
        
        # Initialize conversation
        prompt = [{"role": "user", "content": instruction + user_prompt}]
        prompt = tokenizer.apply_chat_template(prompt, tokenize=False, add_generation_prompt=True)
        
        # Main conversation loop
        while turn < MAX_TURN and search_count < MAX_SEARCH_LIMIT:
            # Generate response
            outputs = llm.generate([prompt])
            response = outputs[0]['text']
            
            # Extract search query if present
            if BEGIN_SEARCH_QUERY in response and END_SEARCH_QUERY in response:
                search_query = response.split(BEGIN_SEARCH_QUERY)[1].split(END_SEARCH_QUERY)[0].strip()
                
                if search_query and search_query not in executed_search_queries:
                    # Perform Wikipedia search
                    search_results = wikipedia_search(search_query, top_k=top_k)
                    relevant_info = extract_relevant_info(search_results)
                    
                    # Format search results
                    search_result_str = json.dumps(relevant_info, ensure_ascii=False, indent=2)
                    response += f"\n{BEGIN_SEARCH_RESULT}\n{search_result_str}\n{END_SEARCH_RESULT}\n"
                    
                    search_count += 1
                    executed_search_queries.add(search_query)
            
            # Update prompt with response
            prompt += response
            
            turn += 1
        
        # Store results
        results.append({
            'Question': question,
            'Output': prompt,
            'Answer': item.get('answer', ''),
            'Correct Choice': item.get('Correct Choice', '')
        })
    
    # Save results
    output_file = os.path.join(output_dir, f'{split}_results.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    # Run evaluation
    run_evaluation(
        filtered_data=results,
        input_list=[r['Output'] for r in results],
        output_list=[{'outputs': [{'text': r['Output']}]} for r in results],
        dataset_name=dataset_name,
        output_dir=output_dir,
        total_time=0,
        split=split
    )

if __name__ == "__main__":
    main() 